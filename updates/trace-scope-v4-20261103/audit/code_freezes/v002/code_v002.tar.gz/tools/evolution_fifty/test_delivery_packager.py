"""Synthetic /tmp packaging tests only, never real publication/admission proof.

Paper archives/reviews, two exporter pins, license text and first-party source
trees below are stubs. No research source is imported from those fixtures, and
no actual result tree, paper archive, RGB/GT/NPY, reference-mutation test,
model, service, Git or network is accessed.
"""
import copy
from dataclasses import replace
import gzip
import io
import json
import os
from pathlib import Path
import tarfile

import pytest

from tools.evolution_fifty import delivery_packager as p


def save(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not isinstance(raw, bytes):
        raw = p.encoded(raw)
    path.write_bytes(raw)
    return dict(path=str(path), sha256=p.sha(raw), bytes=len(raw))


def archive_bytes(members):
    result = io.BytesIO()
    with gzip.GzipFile(fileobj=result, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as tar:
            for name, raw in members:
                header = tarfile.TarInfo(name)
                header.size = len(raw)
                tar.addfile(header, io.BytesIO(raw))
    return result.getvalue()


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    monkeypatch.setenv("CUDA_VISIBLE_DEVICES", "")
    work, results = tmp_path/"hzl", tmp_path/"results"
    work.mkdir(); results.mkdir()
    policy = p.Policy(worktree=work, results=results, metadata_count=2, v002_members=6,
        v002_archive_sha256=None, review_sha256={}, disposition_sha256=None)
    limits = replace(p.Limits(), reserve=0)
    for folder in p.CODE_ROOTS:
        save(work/folder/"synthetic.py", b"# Synthetic source, never executed.\n")
    for path in p.NOTICES:
        save(work/path, b"Synthetic source or notice text; no real license assertion.\n")
    save(work/"trace_ovss/resources/classes.txt", b"background\nsynthetic\n")
    metadata = {}
    for name, raw in {"M01_offline_score_synthetic/ANALYSIS_SEALED.json":b'{"complete":true}\n',
                      "M01_offline_score_synthetic/DATASET_RESULTS.json":b'{"delta":-2,"CI":null}\n'}.items():
        pin = save(policy.metadata/name, raw)
        metadata[name] = dict(sha256=pin["sha256"], bytes=pin["bytes"], identity=["synthetic old identity"])
    registry = save(policy.paper/"generated/source_provenance.json",
                    dict(source_pins=metadata, results_root=str(policy.metadata)))
    papers = []
    for label in ("draft_v001", "draft_v002"):
        composites = [f"figures/case_{i}.png" for i in range(4)]
        contents = {"main.tex": b"Synthetic original paper. Negative and null retained.\n",
                    "generated/source_provenance.json": Path(registry["path"]).read_bytes(),
                    **{n:b"Synthetic derived composite placeholder; no actual pixels." for n in composites}}
        manifest = dict(label=label, members={n:dict(sha256=p.sha(b), bytes=len(b)) for n,b in contents.items()})
        papers.append(dict(label=label, archive=save(policy.paper/"archives"/(label+".tar.gz"),
            archive_bytes(list(contents.items()))), manifest=save(policy.paper/("FREEZE_"+label+".json"),manifest),
            members=len(contents), tar_prefix="", manifest_member=None, derived_composites=composites))
    reviews = {"v001":save(policy.paper/"reviews/manuscript_review_draft_v001.md",b"Synthetic R1 finding.\n"),
               "v002":save(policy.paper/"reviews/manuscript_review_draft_v002_closure.md",b"Synthetic R1 PARTIAL; no acceptance.\n")}
    disposition = save(work/p.DISPOSITION,b"Synthetic disposition: partial construction, negatives retained.\n")
    code_review = save(work/"docs/scope-v4-delivery-code-independent-20261103.md",
                       b"Synthetic CODE report only; not an actual independent closure.\n")
    document = save(work/"docs/M01-risk-results-20261102.md",b"Synthetic negative and null results.\n")
    spec = dict(schema_version=1, papers=papers, exporter_provenance=registry, reviews=reviews,
        disposition=disposition, code_review=code_review, documents=[document], extra_metadata=[],
        config_paths=[], acknowledgements=copy.deepcopy(p.ACK))
    def plan_pin(specification=None, caps=None):
        plan = p.make_plan(specification or spec,policy,caps or limits)
        return save(results/("plan_"+str(len(list(results.glob('plan_*.json'))))+".json"),plan)
    return dict(work=work, results=results, policy=policy, limits=limits, spec=spec,
                plan_pin=plan_pin, tmp=tmp_path)


def destination(f, suffix="packet"):
    return f["results"]/(p.PREFIX+suffix)


def unpack(raw):
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tar:
        return {m.name:tar.extractfile(m).read() for m in tar if m.isfile()}


def test_normal_create_plan_validate_build_and_preserve_bytes(fixture):
    f=fixture
    specpin=save(f["tmp"]/"operator-spec.json",f["spec"])
    created=p.create_plan(specpin,destination(f,"plan"),f["policy"],f["limits"])
    pin={k:created[k] for k in ("path","sha256","bytes")}
    before=set(f["results"].iterdir())
    result=p.validate(pin,f["policy"],f["limits"])
    assert result["valid"] and not result["writes_performed"] and set(f["results"].iterdir())==before
    target=destination(f)
    receipt=p.build(pin,target,f["policy"],f["limits"])
    assert receipt["complete"] is True and receipt["publication_actions_performed"] is False
    assert {x.name for x in target.iterdir()}=={"delivery.tar.gz","MANIFEST.json","LOCAL_VERIFY.json"}
    blobs=unpack((target/"delivery.tar.gz").read_bytes())
    manifest=json.loads((target/"MANIFEST.json").read_bytes())
    assert set(blobs)==set(manifest["archive_member_allowlist"])
    assert blobs["MANIFEST.json"]==(target/"MANIFEST.json").read_bytes()
    for paper in f["spec"]["papers"]:
        assert blobs[f"paper/{paper['label']}/original.tar.gz"]==Path(paper["archive"]["path"]).read_bytes()
    assert blobs["reviews/manuscript_review_draft_v001.md"]==b"Synthetic R1 finding.\n"
    assert blobs["evidence/M01_offline_score_synthetic/DATASET_RESULTS.json"]==b'{"delta":-2,"CI":null}\n'
    assert p.sha((target/"delivery.tar.gz").read_bytes())==receipt["archive"]["sha256"]
    assert "PARTIAL" in blobs["DELIVERY_SCOPE.md"].decode() and "NOT RUN" in blobs["DELIVERY_SCOPE.md"].decode()
    for n in p.NOTICES:
        assert "implementation/current_first_party/"+n in blobs
    with pytest.raises(ValueError,match="already exists"):
        p.build(pin,target,f["policy"],f["limits"])


@pytest.mark.parametrize("key,value",[("local_packaging_authorized",False),
    ("all_referenced_reviews_completed",False),("paper_acceptance_claimed",True),
    ("R1_status","CLOSED"),("publication_actions_authorized",True),
    ("local_packaging_authorized",1)])
def test_requires_explicit_completed_local_partial_ack(fixture,key,value):
    f=fixture;spec=copy.deepcopy(f["spec"]);spec["acknowledgements"][key]=value
    with pytest.raises(ValueError,match="acknowledgements"):
        f["plan_pin"](spec)


def test_actual_production_review_archive_disposition_pins_enforced(fixture):
    f=fixture
    for field in ("v002_archive_sha256","disposition_sha256"):
        policy=replace(f["policy"],**{field:"0"*64})
        with pytest.raises(ValueError,match="pin|archive"):
            p.make_plan(f["spec"],policy,f["limits"])
    policy=replace(f["policy"],review_sha256={"v001":"0"*64,"v002":"0"*64})
    with pytest.raises(ValueError,match="review pin"):
        p.make_plan(f["spec"],policy,f["limits"])


def test_tamper_before_parse_and_metadata_membership(fixture):
    f=fixture;pin=f["plan_pin"]();plan=json.loads(Path(pin["path"]).read_bytes())
    target=Path(plan["source_metadata"][0]["path"]);target.write_bytes(b"not-json same role")
    with pytest.raises(ValueError,match="size|hash"):
        p.validate(pin,f["policy"],f["limits"])
    # A self-consistent plan hash is not permission to change the exporter membership.
    plan["source_metadata"]=[]
    bad=save(f["tmp"]/"bad-plan.json",plan)
    with pytest.raises(ValueError,match="metadata list"):
        p.validate(bad,f["policy"],f["limits"])


@pytest.mark.parametrize("name",["../escape","/absolute","a//b","a/./b","a/../b","a\\b",".env","a\nfile"])
def test_path_traversal_rejected(name):
    with pytest.raises(ValueError):p.relative(name)


def test_paper_undeclared_member_and_traversal_without_extraction(fixture):
    f=fixture;paper=f["spec"]["papers"][0];manifest=Path(paper["manifest"]["path"]).read_bytes()
    contents=list(unpack(Path(paper["archive"]["path"]).read_bytes()).items())
    for name in ("unexpected.txt","../escape"):
        with pytest.raises(ValueError):p.paper_check(archive_bytes(contents+[(name,b"x")]),manifest,paper,f["limits"])
    assert not (f["tmp"]/"escape").exists()


def test_paper_symlink_member_refused(fixture):
    f=fixture;paper=f["spec"]["papers"][0]
    stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode="w") as tar:
        m=tarfile.TarInfo("main.tex");m.type=tarfile.SYMTYPE;m.linkname="elsewhere";tar.addfile(m)
    with pytest.raises(ValueError,match="links"):
        p.paper_check(gzip.compress(stream.getvalue()),Path(paper["manifest"]["path"]).read_bytes(),paper,f["limits"])


def test_symlink_parent_and_leaf_refused(fixture):
    f=fixture;plain=f["tmp"]/"plain.json";plain.write_bytes(b"{}")
    link=f["tmp"]/"leaf.json";link.symlink_to(plain)
    with pytest.raises(ValueError):p.read(link,100)
    parent=f["tmp"]/"aliased";parent.symlink_to(f["work"],target_is_directory=True)
    with pytest.raises(OSError):p.read(parent/"README.md",1024)
    (f["work"]/"tests/aliased.py").symlink_to(plain)
    with pytest.raises(ValueError,match="Symlink"):
        p.code_inventory(f["policy"],[])


def test_hardlinks_and_fifo_refused_before_content_open(fixture,monkeypatch):
    f=fixture;pin=f["plan_pin"]();plan=json.loads(Path(pin["path"]).read_bytes())
    leaf=Path(plan["source_metadata"][0]["path"]);os.link(leaf,f["tmp"]/"duplicate")
    opened=[];real=os.open
    def spy(path,*args,**kwargs):
        if path==leaf.name:opened.append(path)
        return real(path,*args,**kwargs)
    monkeypatch.setattr(p.os,"open",spy)
    with pytest.raises(ValueError,match="single-link"):
        p.validate(pin,f["policy"],f["limits"])
    assert opened==[]
    fifo=f["tmp"]/"fifo.json";os.mkfifo(fifo)
    with pytest.raises(ValueError,match="regular"):p.read(fifo,100)


def test_same_bytes_inode_replacement_during_bounded_read(fixture,monkeypatch):
    f=fixture;leaf=f["tmp"]/"stable.json";raw=b'{"value":null}\n';leaf.write_bytes(raw)
    real=p.os.read;changed=[]
    def replace_during_read(fd,n):
        result=real(fd,n)
        if not changed:
            replacement=f["tmp"]/"replacement.json";replacement.write_bytes(raw);replacement.replace(leaf);changed.append(True)
        return result
    monkeypatch.setattr(p.os,"read",replace_during_read)
    with pytest.raises(ValueError,match="FD/path drift"):p.read(leaf,100,p.sha(raw),len(raw))


def test_source_excludes_payload_vendor_hidden_and_credentials(fixture):
    f=fixture
    for name in ("tests/data/raw.npy","tests/vendor/foreign.py","trace_ovss/.env",
                 "tests/fixtures/payload.py","trace_ovss/secrets.py","trace_ovss/weights/model.bin"):
        save(f["work"]/name,b"EXCLUDED")
    names=p.code_inventory(f["policy"],[])
    assert not any(n.endswith((".npy","foreign.py",".env","payload.py","secrets.py",".bin")) for n in names)
    assert "trace_ovss/synthetic.py" in names
    with pytest.raises(ValueError):p.code_inventory(f["policy"],["tests/data/raw.npy"])


def test_source_membership_drift_refused(fixture):
    f=fixture;pin=f["plan_pin"]();save(f["work"]/"tests/new.py",b"# Unexecuted new source\n")
    with pytest.raises(ValueError,match="membership differs"):
        p.validate(pin,f["policy"],f["limits"])


def test_foreign_and_existing_output_never_changed(fixture):
    f=fixture;pin=f["plan_pin"]();foreign=f["tmp"]/"foreign";foreign.mkdir();sentinel=foreign/"keep";sentinel.write_bytes(b"keep")
    with pytest.raises(ValueError,match="Foreign"):
        p.build(pin,foreign,f["policy"],f["limits"])
    existing=destination(f);existing.mkdir();save(existing/"keep",b"keep")
    with pytest.raises(ValueError,match="already exists"):
        p.build(pin,existing,f["policy"],f["limits"])
    assert sentinel.read_bytes()==b"keep" and (existing/"keep").read_bytes()==b"keep"


@pytest.mark.parametrize("field,value",[("code",4),("metadata",4),("total",1),("paper_expanded",32),("package",32),("members",3)])
def test_caps_refuse_without_completed_output(fixture,field,value):
    f=fixture;limits=replace(f["limits"],**{field:value})
    with pytest.raises((ValueError,EOFError)):
        pin=f["plan_pin"](caps=limits)
        p.build(pin,destination(f),f["policy"],limits)
    assert not (destination(f)/"LOCAL_VERIFY.json").exists()


def test_disk_reserve_refuses_before_destination(fixture,monkeypatch):
    f=fixture;pin=f["plan_pin"]()
    monkeypatch.setattr(p.shutil,"disk_usage",lambda _:type("Usage",(),{"free":0})())
    with pytest.raises(ValueError,match="reserve"):
        p.build(pin,destination(f),f["policy"],f["limits"])
    assert not destination(f).exists()


@pytest.mark.parametrize("phase",["delivery.tar.gz","MANIFEST.json","LOCAL_VERIFY.json"])
def test_ordinary_write_failures_are_owned_failed_and_not_resumed(fixture,monkeypatch,phase):
    f=fixture;pin=f["plan_pin"]();original=p.OwnedOutput.write
    def fail(self,name,raw):
        if name==phase:raise OSError("Synthetic ordinary write failure")
        return original(self,name,raw)
    monkeypatch.setattr(p.OwnedOutput,"write",fail)
    with pytest.raises(OSError):p.build(pin,destination(f),f["policy"],f["limits"])
    assert json.loads((destination(f)/"FAILED.json").read_bytes())["complete"] is False
    assert not (destination(f)/"LOCAL_VERIFY.json").exists()
    with pytest.raises(ValueError,match="already exists"):
        p.build(pin,destination(f),f["policy"],f["limits"])


def test_no_project_or_io_action_imports():
    import ast
    tree=ast.parse(Path(p.__file__).read_text())
    names={n.names[0].name.split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.Import)}
    assert not names.intersection({"torch","numpy","PIL","cv2","subprocess","socket","requests","urllib"})


def test_full_handoff_and_nonallowlisted_result_payload_refused(fixture):
    f=fixture;spec=copy.deepcopy(f["spec"])
    spec["documents"]=[save(f["work"]/"docs/self-evolution-handoff.md",b"Must not bundle full handoff")]
    with pytest.raises(ValueError,match="handoffs"):
        f["plan_pin"](spec)
    for path in (f["policy"].metadata/"x/predictions/DATASET_RESULTS.json",
                 f["policy"].metadata/"x/cost.jsonl",f["tmp"]/"RESULT.json"):
        with pytest.raises(ValueError):p.metadata_path(dict(path=str(path)),f["policy"])


def test_exporter_registry_must_match_frozen_v002_member(fixture):
    f=fixture;spec=copy.deepcopy(f["spec"])
    path=Path(spec["exporter_provenance"]["path"])
    registry=json.loads(path.read_bytes());registry["new_unreviewed_annotation"]="not in frozen paper"
    spec["exporter_provenance"]=save(path,registry)
    pin=f["plan_pin"](spec)
    with pytest.raises(ValueError,match="exact reviewed v002"):
        p.build(pin,destination(f),f["policy"],f["limits"])
    assert not destination(f).exists()


def test_local_verification_refuses_tamper_and_failed_packet(fixture):
    f=fixture;pin=f["plan_pin"]();target=destination(f)
    p.build(pin,target,f["policy"],f["limits"])
    path=target/"LOCAL_VERIFY.json"
    receipt_pin=dict(path=str(path),sha256=p.sha(path.read_bytes()),bytes=path.stat().st_size)
    assert p.verify_delivery(target,receipt_pin,f["policy"],f["limits"])["complete"]
    save(target/"FAILED.json",dict(complete=False))
    with pytest.raises(ValueError,match="Failed"):
        p.verify_delivery(target,receipt_pin,f["policy"],f["limits"])
    (target/"FAILED.json").unlink()
    with (target/"delivery.tar.gz").open("ab") as stream:stream.write(b"tampered")
    with pytest.raises(ValueError,match="size|hash"):
        p.verify_delivery(target,receipt_pin,f["policy"],f["limits"])


def test_verifier_refuses_self_consistent_extra_tar_member(fixture):
    f=fixture;pin=f["plan_pin"]();target=destination(f)
    p.build(pin,target,f["policy"],f["limits"])
    members=list(unpack((target/"delivery.tar.gz").read_bytes()).items())
    members.append(("unexpected.txt",b"Undeclared harmless text"))
    archive=archive_bytes(members);save(target/"delivery.tar.gz",archive)
    receipt=json.loads((target/"LOCAL_VERIFY.json").read_bytes())
    receipt["archive"]=dict(sha256=p.sha(archive),bytes=len(archive))
    receipt_pin=save(target/"LOCAL_VERIFY.json",receipt)
    with pytest.raises(ValueError,match="type/member"):
        p.verify_delivery(target,receipt_pin,f["policy"],f["limits"])


def test_paper_hidden_trailing_bytes_refused(fixture):
    f=fixture;paper=f["spec"]["papers"][0]
    expanded=gzip.decompress(Path(paper["archive"]["path"]).read_bytes())+b"UNDECLARED"
    with pytest.raises(ValueError,match="trailing paper"):
        p.paper_check(gzip.compress(expanded),Path(paper["manifest"]["path"]).read_bytes(),paper,f["limits"])


def test_read_error_and_close_error_do_not_leak_directory_fds(fixture,monkeypatch):
    f=fixture;leaf=f["tmp"]/"ordinary.json";leaf.write_bytes(b"{}")
    opened=set();targets=set();faults=[];real_open=p.os.open;real_close=p.os.close
    def open_spy(path,flags,*args,**kwargs):
        fd=real_open(path,flags,*args,**kwargs);opened.add(fd)
        if path==leaf.name:targets.add(fd)
        return fd
    def close_spy(fd):
        real_close(fd);opened.discard(fd)
        if fd in targets and not faults:
            targets.discard(fd);faults.append(True);raise OSError("Synthetic close error after actual close")
        targets.discard(fd)
    monkeypatch.setattr(p.os,"open",open_spy);monkeypatch.setattr(p.os,"close",close_spy)
    with pytest.raises(OSError,match="close error"):p.read(leaf,100)
    assert opened==set()
    for _ in range(20):
        with pytest.raises(ValueError,match="hash mismatch"):p.read(leaf,100,"0"*64)
    assert opened==set()


@pytest.mark.parametrize("phase",["delivery.tar.gz","LOCAL_VERIFY.json"])
def test_actual_output_close_errors_fail_and_receipt_cannot_override_failure(fixture,monkeypatch,phase):
    f=fixture;pin=f["plan_pin"]();target=destination(f)
    targets=set();faults=[];real_open=p.os.open;real_close=p.os.close
    def opening(path,flags,*args,**kwargs):
        fd=real_open(path,flags,*args,**kwargs)
        if path==phase and flags & os.O_WRONLY:targets.add(fd)
        return fd
    def closing(fd):
        real_close(fd)
        if fd in targets and not faults:
            targets.discard(fd);faults.append(True);raise OSError("Synthetic actual writer close error")
        targets.discard(fd)
    monkeypatch.setattr(p.os,"open",opening);monkeypatch.setattr(p.os,"close",closing)
    with pytest.raises(OSError,match="writer close"):
        p.build(pin,target,f["policy"],f["limits"])
    assert faults and (target/"FAILED.json").exists()
    if (target/"LOCAL_VERIFY.json").exists():
        path=target/"LOCAL_VERIFY.json";receipt_pin=dict(path=str(path),sha256=p.sha(path.read_bytes()),bytes=path.stat().st_size)
        with pytest.raises(ValueError,match="Failed"):
            p.verify_delivery(target,receipt_pin,f["policy"],f["limits"])


def test_output_context_exit_error_precedes_completion_receipt(fixture,monkeypatch):
    f=fixture;pin=f["plan_pin"]();original=p.OwnedOutput.__exit__;faults=[]
    def exit_error(self,*exc):
        original(self,*exc)
        if not faults:faults.append(True);raise OSError("Synthetic output context exit error")
    monkeypatch.setattr(p.OwnedOutput,"__exit__",exit_error)
    with pytest.raises(OSError,match="context exit"):
        p.build(pin,destination(f),f["policy"],f["limits"])
    assert (destination(f)/"FAILED.json").exists() and not (destination(f)/"LOCAL_VERIFY.json").exists()


def test_final_written_manifest_identity_not_rebased(fixture,monkeypatch):
    f=fixture;pin=f["plan_pin"]();target=destination(f);original=p.read;changed=[]
    def swap(path,*args,**kwargs):
        if Path(path)==target/"MANIFEST.json" and not changed:
            leaf=Path(path);raw=leaf.read_bytes();save(target/"replacement.json",raw)
            (target/"replacement.json").replace(leaf);changed.append(True)
        return original(path,*args,**kwargs)
    monkeypatch.setattr(p,"read",swap)
    with pytest.raises(ValueError,match="before open"):
        p.build(pin,target,f["policy"],f["limits"])
    assert changed and (target/"FAILED.json").exists() and not (target/"LOCAL_VERIFY.json").exists()


def test_cli_dispatch_is_explicit_and_does_not_build_on_validate(fixture,monkeypatch,capsys):
    f=fixture;pin=f["plan_pin"]();calls=[]
    monkeypatch.setattr(p,"validate",lambda value:calls.append(value) or dict(valid=True,writes_performed=False))
    monkeypatch.setattr(p.sys,"argv",["delivery_packager","validate","--plan",pin["path"],"--sha256",pin["sha256"]])
    p.main()
    assert calls==[pin] and json.loads(capsys.readouterr().out)["writes_performed"] is False


def test_additional_new_code_reports_are_explicit_and_old_grades_refused(fixture):
    f=fixture;spec=copy.deepcopy(f["spec"])
    raw=b"Synthetic additional new CODE findings, unchanged and not graded.\n"
    spec["additional_code_reviews"]=[save(f["work"]/"docs/scope-v4-exporter-code-independent-20261103.md",raw)]
    pin=f["plan_pin"](spec);p.build(pin,destination(f),f["policy"],f["limits"])
    blobs=unpack((destination(f)/"delivery.tar.gz").read_bytes())
    assert blobs["reviews/code/scope-v4-exporter-code-independent-20261103.md"]==raw
    spec["additional_code_reviews"]=[save(f["work"]/"docs/round05_grade.md",b"Excluded old grade")]
    with pytest.raises(ValueError,match="old grades"):
        f["plan_pin"](spec)


@pytest.mark.parametrize('action', ['verify', 'build'])
@pytest.mark.parametrize('change', ['failed', 'manifest', 'manifest_same_bytes',
                                    'receipt_same_bytes', 'archive_same_bytes'])
def test_final_verification_rebinds_membership_and_all_leaves(fixture, monkeypatch, action, change):
    f = fixture
    pin = f['plan_pin']()
    target = destination(f)
    if action == 'verify':
        p.build(pin, target, f['policy'], f['limits'])
    original_read, original_verify = p.read, p.verify_delivery
    active, changed = [], []
    def late_change(path, *args, **kwargs):
        result = original_read(path, *args, **kwargs)
        if active and Path(path) == target/'delivery.tar.gz' and not changed:
            changed.append(True)
            if change == 'failed':
                save(target/'FAILED.json', dict(complete=False))
            else:
                name = ('MANIFEST.json' if change.startswith('manifest') else
                        'LOCAL_VERIFY.json' if change.startswith('receipt') else 'delivery.tar.gz')
                leaf = target/name
                raw = leaf.read_bytes() if change.endswith('same_bytes') else b'{"replacement":true}\n'
                replacement = target/'synthetic-replacement'
                save(replacement, raw)
                replacement.replace(leaf)
        return result
    def verifying(*args, **kwargs):
        active.append(True)
        try:
            return original_verify(*args, **kwargs)
        finally:
            active.pop()
    monkeypatch.setattr(p, 'read', late_change)
    monkeypatch.setattr(p, 'verify_delivery', verifying)
    with pytest.raises(ValueError, match='Failed|Final output leaf'):
        if action == 'build':
            p.build(pin, target, f['policy'], f['limits'])
        else:
            receipt_path = target/'LOCAL_VERIFY.json'
            receipt_pin = dict(path=str(receipt_path), sha256=p.sha(receipt_path.read_bytes()),
                               bytes=receipt_path.stat().st_size)
            p.verify_delivery(target, receipt_pin, f['policy'], f['limits'])
    assert changed
    if action == 'build':
        assert (target/'FAILED.json').exists()


def test_directory_fstat_exception_closes_new_child(fixture, monkeypatch):
    folder = fixture['tmp']/'ordinary-directory'
    folder.mkdir()
    opened, children, faults = set(), set(), []
    original_open, original_close, original_fstat = p.os.open, p.os.close, p.os.fstat
    def opening(path, flags, *args, **kwargs):
        fd = original_open(path, flags, *args, **kwargs)
        opened.add(fd)
        if path == folder.name:
            children.add(fd)
        return fd
    def closing(fd):
        original_close(fd)
        opened.discard(fd)
        children.discard(fd)
    def stating(fd):
        if fd in children and not faults:
            faults.append(True)
            raise OSError('Synthetic child fstat failure')
        return original_fstat(fd)
    monkeypatch.setattr(p.os, 'open', opening)
    monkeypatch.setattr(p.os, 'close', closing)
    monkeypatch.setattr(p.os, 'fstat', stating)
    with pytest.raises(OSError, match='child fstat'):
        with p.directory(folder):
            pytest.fail('Faulted directory must not yield')
    assert faults and not opened


def test_namespace_change_during_final_leaf_rebind_is_not_adopted(fixture, monkeypatch):
    f = fixture
    target = destination(f)
    p.build(f['plan_pin'](), target, f['policy'], f['limits'])
    leaf = target/'LOCAL_VERIFY.json'
    receipt_pin = dict(path=str(leaf), sha256=p.sha(leaf.read_bytes()), bytes=leaf.stat().st_size)
    original_read, original_observe = p.read, p.observe
    parsed_archive, changed = [], []
    def reading(path, *args, **kwargs):
        result = original_read(path, *args, **kwargs)
        if Path(path) == target/'delivery.tar.gz':
            parsed_archive.append(True)
        return result
    def observing(path, *args, **kwargs):
        result = original_observe(path, *args, **kwargs)
        if parsed_archive and Path(path) == target/'delivery.tar.gz' and not changed:
            changed.append(True)
            manifest = target/'MANIFEST.json'
            replacement = target/'synthetic-replacement'
            save(replacement, manifest.read_bytes())
            replacement.replace(manifest)
        return result
    monkeypatch.setattr(p, 'read', reading)
    monkeypatch.setattr(p, 'observe', observing)
    with pytest.raises(ValueError, match='directory membership drift'):
        p.verify_delivery(target, receipt_pin, f['policy'], f['limits'])
    assert changed
